# hibernate


mysqld -P3306 --skip-grant-tables

mysql -P3306 mysql

update mysql.user set authentication_string=password('admin') where user='root'; 


